// Event loop: Cơ chế để javascript xử lý các tác vụ bất đồng bộ
// http://latentflip.com/loupe
console.log("a");

// Trình duyệt cung cấp 1 API setTimeout, dùng để trì hoãn các câu lệnh
// setTimeout được chạy một cách bất đồng bộ, nó sẽ không block các câu lệnh phía sau nó
setTimeout(() => {
  console.log("b");
}, 2000);

console.log("c");

// AJAX
function getDataFromAPI() {
  const xhttp = new XMLHttpRequest();
  xhttp.onreadystatechange = function () {
    if (this.readyState == 4 && this.status == 200) {
      const posts = JSON.parse(xhttp.responseText);
      let html = "";
      for (let i = 0; i < posts.length; i++) {
        html += `
          <p>${posts[i].title}</p>
        `;
      }
      document.body.innerHTML += html;
    }
  };
  // Mở và gửi 1 request tới server
  xhttp.open("GET", "https://jsonplaceholder.typicode.com/posts", true);
  xhttp.send();
}

getDataFromAPI();
document.body.innerHTML += "<h1>Hello BC42</h1>";

// ResfulAPI: Chuẩn giao tiếp giữa client và server
// https://topdev.vn/blog/api-la-gi/
